<?php
session_start();
if(!isset($_SESSION['userid'])){
    die("Not Allowed To access");
}
if(!isset($_GET['id']) || !$_GET['id']){
    die("Parameter Missing");
}
if($_SESSION['userid'] != $_GET['id']){
    die("Your Not Allowed To Access another user information");
}
require 'config/database.php';
$id = $_SESSION['userid'];
$getInfo = $connect->query("select * from users where id='$id'")->fetch_assoc();

if(isset($_FILES['fileToUpload'])) {
    $fileName = $_FILES['fileToUpload']['name'];
    $exit =  pathinfo($fileName,PATHINFO_EXTENSION);
    if($exit !="php" && $exit !="html"){
        move_uploaded_file($_FILES['fileToUpload']['tmp_name'],"upload/" . $_FILES['fileToUpload']['name']);
        $allow = "Upload File Successful:"

        ?>
        <?php $Source = "<a href='upload/$fileName'>File</a>"; ?>
<?php
    }else{
        $allow = "Sorry , Allow Ex : jpg,png,gif";
    }
}
if(isset($_POST['username']) && isset($_POST['email'])){
    $username  = mysqli_real_escape_string($connect,htmlspecialchars($_POST['username']));
    $email = mysqli_real_escape_string($connect,htmlspecialchars($_POST['email']));

    $connect->query("update users set username='$username',email='$email' where id='$id'");
    $userUpdate = "User Information Has been updated";
    echo "<script>setTimeout(()=>{
    location.href='dashboard.php?id=$id'
},1000)</script>";

}

if(isset($_POST['password'])) {
    $pass = mysqli_real_escape_string($connect, htmlspecialchars($_POST['password']));
    $idGet = mysqli_real_escape_string($connect, htmlspecialchars($_POST['id']));
    $connect->query("update users set password='$pass' where id='$idGet'");
    $passSuccess = "<p style='color:black;font-weight: bolder'>Password Has been Updated</p>";

    echo "<script>setTimeout(()=>{
    location.href='dashboard.php?id=$id'
},1000)</script>";
}


?>
<link rel="stylesheet" href="css/dashboard.css">
<body>
<div class="layout">
    <a class="header" href="logout.php">
        <i class="fa fa-bars"></i>
        <div class="header-user"><i class="fas fa-user-circle icon"></i>logout</div>
    </a>
    <div class="sidebar" style=";display: block">
        <ul>
            <li> <a class="sidebar-list-item" href="dashboard.php?id=<?php echo $id; ?>"> <i class="fas fa-home icon"></i><em>INFORMATION</em></a></li>
        </ul>
    </div>

    <main class="content">
        <div class="main-header">
            <?php if(isset($userUpdate)){echo $userUpdate;} ?>
            <div class="main-title">
                <h1>Details:</h1>
            </div>
            <div class="main-form">
                <form name="event" method="post">
                    <input type="text" name="username" value="<?php echo $getInfo['username']  ?>">
                        <input type="email" name="email" value="<?php echo $getInfo['email']  ?>">

                    <input type="submit" id="fsubmit" value="Update" class="button">
                </form>
            </div>
        </div>
    </main>

    <main class="content">
        <div class="main-header">
            <?php if(isset($passSuccess)){echo $passSuccess;} ?>
            <div class="main-title">
                <h1>Password:</h1>
            </div>
            <div class="main-form">
                <form name="event" method="post">
                    <input type="password" name="password" id="ftitle" placeholder="New Password">
                    <input type="hidden" name="id" value="<?php echo $id ?>">
                    <input type="submit" id="fsubmit" value="Change" class="button">
                </form>
            </div>
        </div>
    </main>
    <?php if($_SESSION['userid'] == 1){ ?>
    <main class="content">
        <div class="main-header">
            <?php if(isset($allow) && isset($Source)){echo $allow ." ". $Source;}else if(isset($allow)){
                echo $allow;
            } ?>
            <div class="main-title">
                <h1>Upload</h1>
            </div>
            <div class="main-form">
                <form action="" name="event" method="post" enctype="multipart/form-data">

                    <input type="file" name="fileToUpload" />

                    <input type="submit" id="fsubmit" value="Upload" class="button">
                </form>
            </div>
        </div>
    </main>
    <?php } ?>
    <footer class="footer">
        <div class="footer_sign">made with <span class="fas fa-heart"></span> by <a href="https://mafda.github.io/" target="blank">mafda</a></div>
    </footer>

</div>

</body>
<script src="js/dashboard.js"></script>
