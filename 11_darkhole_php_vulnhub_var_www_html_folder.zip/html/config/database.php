<?php
$connect = new mysqli("localhost",'john','john','darkhole');
